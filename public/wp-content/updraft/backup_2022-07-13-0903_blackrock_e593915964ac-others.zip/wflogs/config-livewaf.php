<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:2:{s:4:"cron";a:3:{i:0;O:24:"wfWAFCronFetchRulesEvent":1:{s:11:" * fireTime";i:1657720664;}i:1;O:25:"wfWAFCronFetchIPListEvent":1:{s:11:" * fireTime";i:1657700751;}i:2;O:36:"wfWAFCronFetchBlacklistPrefixesEvent":1:{s:11:" * fireTime";i:1657621551;}}s:20:"whitelistedURLParams";a:1:{s:81:"L3dwLWFkbWluL2FkbWluLnBocA==|cmVxdWVzdC5ib2R5W2FjZl1bZmllbGRfNjJiMzQ2OGI4OWZjMV0=";a:1:{i:9;a:4:{s:9:"timestamp";i:1657615632;s:11:"description";s:37:"Allowlisted via false positive dialog";s:6:"source";s:14:"false-positive";s:2:"ip";s:9:"127.0.0.1";}}}}